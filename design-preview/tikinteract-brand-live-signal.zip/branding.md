# Current branding — TI / LIVE signal

The user approved the supplied TI monogram with LIVE signal arcs and the `TikInteract` wordmark. The active artwork is native SVG: manually defined symbol paths and outlined glyphs from the project's licensed Inter font. No bitmap tracing, embedded raster images, external fonts, masks or blur effects are used. All seven assets were inspected at enlarged size and 2× display density.

- `assets/tikinteract-brand-light.svg` / `-dark.svg`: horizontal symbol + wordmark used on the website, footer, game presentation pages, information pages, Support and administration.
- `assets/tikinteract-symbol-light.svg` / `-dark.svg`: symbol only, used in the Studio sidebar (60px desktop, 46px mobile).
- `assets/tikinteract-brand-stacked-light.svg` / `-dark.svg`: full stacked lockup with the approved reference tagline, available for export; not added to the website content.
- `assets/tikinteract-app-icon.svg`: square app icon and site favicon.

Dark Mode uses lighter Burgundy stops for legibility. Light Mode follows the charcoal/Burgundy palette from the reference. The site header follows the same 1200px content edges, including matching responsive margins. Studio has no top-bar logo; only its sidebar symbol remains.

Studio navigation now shows STREAM, Games, SOUND PAD and STATS in the main group. Back to site is followed by My Account, Help and Community in the lower group. The original authenticated avatar element is moved beside the notifications bell and opens Profile. The gift catalog tab/panel is removed from Studio; gift recording, public collections and game triggers remain native.

Studio uses its full available width, 18px desktop column gaps and 24px gaps on large screens. Local browser verification covered 1920/1440/1100/1000/768/390/320px, both modes, lower navigation, profile, notification dropdown, header alignment, RO/EN and zero JavaScript exceptions. The 23 relevant routing, Studio authentication and gift-data tests also passed. No deployment, commit or production data write was performed.

Earlier proposed assets remain unused references. The local Inter font license is included in `assets/fonts/inter-OFL.txt`.
